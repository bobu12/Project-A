<?php

include_once 'connection.php';
if(isset($_SESSION['username'])){
    unset($_SESSION['username']);
}
$_SESSION['err_msg'] = "Logged out successfully.";
header("location: /");
exit(0);
