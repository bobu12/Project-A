<?php
include_once 'connection.php';
if (!isset($_SESSION['username'])) {
    $_SESSION['err_msg'] = "You are not logged in.";
    header("location: /");
    exit(0);
}
$err_msg = '';
if (isset($_SESSION['err_msg'])) {
    $err_msg = $_SESSION['err_msg'];
    unset($_SESSION['err_msg']);
}
$conf_msg = '';
if (isset($_SESSION['conf_msg'])) {
    $conf_msg = $_SESSION['conf_msg'];
    unset($_SESSION['conf_msg']);
}
$product_details = executeQuery("SELECT product_id, product_name,product_desc, product_video_file_mime_type FROM `product_details` ");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script>
            function ValidateForm() {
                document.getElementById('err_msg').innerHTML = '';
                var product_photo = document.getElementById('product_photo').value;
                var ext = product_photo.substr(product_photo.lastIndexOf("."));
                if (ext !== ".jpeg" && ext !== ".jpg" && ext !== ".png" && ext !== ".bmp" && ext !== ".gif") {
                    document.getElementById('err_msg').innerHTML = "Photo file extension is not allowed";
                    return false;
                }
                var product_thumbnail = document.getElementById('product_thumbnail').value;
                var ext = product_thumbnail.substr(product_thumbnail.lastIndexOf("."));
                if (ext !== ".jpeg" && ext !== ".jpg" && ext !== ".png" && ext !== ".bmp" && ext !== ".gif") {
                    document.getElementById('err_msg').innerHTML = "Thumbnail file extension is not allowed";
                    return false;
                }
                var product_video = document.getElementById('product_video').value;
                var ext = product_video.substr(product_video.lastIndexOf("."));
                if (ext !== ".3gp" && ext !== ".mp4" && ext !== ".mpeg" && ext !== ".mpg") {
                    document.getElementById('err_msg').innerHTML = "Video file extension is not allowed";
                    return false;
                }
                return true;
            }
        </script>
    </head>
    <body>
        <div style="width:100%;height: 30px;"><a href="logout.php" style="float:right;margin: 10px 20px 0 0;">Log Out</a></div>
        <h3>Product Entry</h3>
        <form name="productEntryForm" id="productEntryForm" action="productEntry.php" method="POST" onsubmit="return ValidateForm();" enctype="multipart/form-data">
            <label for="product_name" style="width:100px;float:left;">Product Name: </label><input type="text" name="product_name" id="product_name" value="" maxlength="150" required placeholder="Enter Product Name" style="width:200px;float:left;margin-bottom: 5px;"/>
            <div style="clear:both;"></div>
            <label for="product_desc" style="width:100px;float:left;">Product Desc: </label><textarea name="product_desc" id="product_desc" maxlength="1000" placeholder="Enter Product Name" style="width:200px;float:left;margin-bottom: 5px;height: 40px;"></textarea>
            <div style="clear:both;"></div>
            <label for="product_photo" style="width:100px;float:left;">Photo: </label><input type="file" name="product_photo" id="product_photo" style="width:200px;float:left;margin-bottom: 5px;" accept="image/*"/>
            <div style="clear:both;"></div>
            <label for="product_thumbnail" style="width:100px;float:left;">Thumbnail: </label><input type="file" name="product_thumbnail" id="product_thumbnail" style="width:200px;float:left;margin-bottom: 5px;" accept="image/*"/>
            <div style="clear:both;"></div>
            <label for="product_video" style="width:100px;float:left;">Video: </label><input type="file" name="product_video" id="product_video" style="width:200px;float:left;margin-bottom: 5px;" accept="video/*"/>
            <div style="clear:both;"></div>
            <label style="width:100px;float:left;">&nbsp;</label><input type="submit" name="submit" id="submit" value="Submit" style="float:left;padding: 5px 10px;"/>
            <div style="float:left;padding-top:4px;padding-left: 6px;color:red;" id="err_msg"><?php echo $err_msg; ?></div>
            <div style="float:left;padding-top:4px;padding-left: 6px;color:green;"><?php echo $conf_msg; ?></div>
            <div style="clear:both;"></div>
        </form>
        <br/>
        <h3>Products</h3>
        <table width="100%" border="0" style="border:#000 1px solid;" rules="all">
            <tr>
                <th width="5%">Sl.</th>
                <th width="20%">Product Name</th>
                <th width="30%">Description</th>
            </tr>
            <?php $i = 1; ?>
            <?php while ($r = mysqli_fetch_object($product_details)) { ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $r->product_name; ?></td>
                    <td><?php echo $r->product_desc; ?></td>
                </tr>
                <?php $i++; ?>
            <?php } ?>
            <?php echo $i == 1 ? '<tr><td colspan="3">No Record Found</td></tr>' : ''; ?>
        </table>
    </body>
</html>
