<?php

include_once 'connection.php';
if (isset($_POST['product_name'])) {
    $data = array();
    $data['product_name'] = $_POST['product_name'];
    $data['product_desc'] = $_POST['product_desc'];
    $data['product_photo_file_name'] = NULL;
    $data['product_photo_file_mime_type'] = NULL;
    $data['product_photo'] = NULL;
    $data['product_thumbnail_file_name'] = NULL;
    $data['product_thumbnail_file_mime_type'] = NULL;
    $data['product_thumbnail'] = NULL;
    $data['product_video_file_name'] = NULL;
    $data['product_video_file_mime_type'] = NULL;
    $data['product_video'] = NULL;

    $pathname = "./uploads";
    if (!file_exists($pathname)) {
        mkdir($pathname);
    }

    if (isset($_FILES['product_photo']) && basename($_FILES['product_photo']['name']) != '') {
        $data['product_photo_file_name'] = $file_name = isset($_FILES['product_photo']) ? basename($_FILES['product_photo']['name']) : '';
        $ext = strrchr($file_name, '.');
        //$filename = str_replace($ext, '', $file_name);
        if (strtolower($ext) != ".jpg" && strtolower($ext) != ".jpeg" && strtolower($ext) != ".png" && strtolower($ext) != ".bmp" && strtolower($ext) != ".gif") {
            $_SESSION['err_msg'] = "Product Photo File Extension not allowed";
            header("location: dashboard.php");
            exit(0);
        }
        if (!move_uploaded_file($_FILES['product_photo']['tmp_name'], $pathname . "/" . $file_name)) {
            $_SESSION['err_msg'] = "Product Photo File Could not upload";
            header("location: dashboard.php");
            exit(0);
        }
        $data['product_photo_file_mime_type'] = mime_content_type($pathname . "/" . $file_name);
        $data['product_photo'] = file_get_contents($pathname . "/" . $file_name);
        unlink($pathname . "/" . $file_name);
    }
    if (isset($_FILES['product_thumbnail']) && basename($_FILES['product_thumbnail']['name']) != '') {
        $data['product_thumbnail_file_name'] = $file_name = isset($_FILES['product_thumbnail']) ? basename($_FILES['product_thumbnail']['name']) : '';
        $ext = strrchr($file_name, '.');
        //$filename = str_replace($ext, '', $file_name);
        if (strtolower($ext) != ".jpg" && strtolower($ext) != ".jpeg" && strtolower($ext) != ".png" && strtolower($ext) != ".bmp" && strtolower($ext) != ".gif") {
            $_SESSION['err_msg'] = "Product thumbnail File Extension not allowed";
            header("location: dashboard.php");
            exit(0);
        }
        if (!move_uploaded_file($_FILES['product_thumbnail']['tmp_name'], $pathname . "/" . $file_name)) {
            $_SESSION['err_msg'] = "Product thumbnail File Could not upload";
            header("location: dashboard.php");
            exit(0);
        }
        $data['product_thumbnail_file_mime_type'] = mime_content_type($pathname . "/" . $file_name);
        $data['product_thumbnail'] = file_get_contents($pathname . "/" . $file_name);
        unlink($pathname . "/" . $file_name);
    }
    if (isset($_FILES['product_video']) && basename($_FILES['product_video']['name']) != '') {
        $data['product_video_file_name'] = $file_name = isset($_FILES['product_video']) ? basename($_FILES['product_video']['name']) : '';
        $ext = strrchr($file_name, '.');
        //$filename = str_replace($ext, '', $file_name);
        if (strtolower($ext) != ".3gp" && strtolower($ext) != ".mp4" && strtolower($ext) != ".mpeg" && strtolower($ext) != ".mpg") {
            $_SESSION['err_msg'] = "Product video File Extension not allowed";
            header("location: dashboard.php");
            exit(0);
        }
        if (!move_uploaded_file($_FILES['product_video']['tmp_name'], $pathname . "/" . $file_name)) {
            $_SESSION['err_msg'] = "Product video File Could not upload";
            header("location: dashboard.php");
            exit(0);
        }
        $data['product_video_file_mime_type'] = mime_content_type($pathname . "/" . $file_name);
        $data['product_video'] = file_get_contents($pathname . "/" . $file_name);
        unlink($pathname . "/" . $file_name);
    }

    $result = executeInsert('product_details', $data);
    if (is_int($result) && $result > 0) {
        $_SESSION['conf_msg'] = "Successfully Added";
    } else {
        $_SESSION['err_msg'] = "Not Successfully Added";
    }
}
header("location: dashboard.php");
exit(0);
