<?php

session_start();
ob_start();

function mysqli_con_info() {
    $server = "database-2019.cmh8v3owvkuf.us-west-2.rds.amazonaws.com";
    $username = "admin";
    $password = "Baby7890";
    $database_name = "innodb";

    $link_identifier = mysqli_connect($server, $username, $password, $database_name) or die("Couldn't connect to database server");
    return $link_identifier;
}

function executeInsert($table_name, $data) {
    $con = mysqli_con_info();
    $query = "";
    foreach ($data as $k => $v)
        $query .= ($query == "" ? "" : ",").(!is_null($v) ? "'".mysqli_real_escape_string($con, $v)."'" : "NULL");
    $query = "INSERT INTO `$table_name` (`" . implode('`,`', array_keys($data)) . "`) VALUES (" . $query . ")";
    $data_id = mysqli_query($con, $query) or die(mysqli_error($con));
    $r = $data_id !== FALSE ? mysqli_insert_id($con) : $data_id;
    return $r;
}

function executeQuery($query) {
    $con = mysqli_con_info();
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    return $result;
}

/*
 * End of file connection.php
 */

