<?php

include_once 'connection.php';
if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = executeQuery("SELECT COUNT(*) As `rows` FROM `login` WHERE `username` = '$username' AND `password` = '$password' ");
    $data = mysqli_fetch_object($result);
    if (!is_null($data) && $data->rows == 1) {
        $_SESSION['username'] = $username;
        header("location: dashboard.php");
        exit(0);
    } else {
        $_SESSION['err_msg'] = "Log In Failed";
        header("location: /");
        exit(0);
    }
}
$_SESSION['err_msg'] = "You are not logged in.";
header("location: /");
exit(0);
