<?php
include_once 'connection.php';
if (isset($_SESSION['username'])) {
    header("location: dashboard.php");
    exit(0);
}
$err_msg = '';
if (isset($_SESSION['err_msg'])) {
    $err_msg = $_SESSION['err_msg'];
    unset($_SESSION['err_msg']);
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div style="width: 350px;margin: 0 auto;margin-top: 10%;height: auto;border:#000 1px solid;padding: 10px 5px; background: #ccc;">
            <h3>Log In</h3>
            <form name="logInForm" id="logInForm" action="logInProc.php" method="POST">
                <label for="username" style="width:100px;float:left;">Username: </label><input type="text" name="username" id="username" value="" maxlength="20" required placeholder="Enter Username" style="width:200px;float:left;margin-bottom: 5px;"/>
                <div style="clear:both;"></div>
                <label for="password" style="width:100px;float:left;">Password: </label><input type="password" name="password" id="password" value="" required placeholder="Enter Password" style="width:200px;float:left;margin-bottom: 5px;"/>
                <div style="clear:both;"></div>
                <label style="width:100px;float:left;">&nbsp;</label><input type="submit" name="submit" id="submit" value="Log In" style="float:left;padding: 5px 10px;"/>
                <div style="float:left;padding-top:4px;padding-left: 6px;color:red;"><?php echo $err_msg; ?></div>
                <div style="clear:both;"></div>
            </form>
        </div>
    </body>
</html>
